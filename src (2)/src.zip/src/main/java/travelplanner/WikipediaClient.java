package travelplanner;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;

/**
 * Fetches a one-line description from Wikipedia for places that end up in the itinerary.
 * Completely optional: any failure just returns null and the planner uses a generic description.
 */
public class WikipediaClient {

    private static final String SUMMARY_URL = "https://en.wikipedia.org/api/rest_v1/page/summary/";
    private boolean networkWorking = true;   // after one network failure we stop trying (saves time)

    /**
     * @param wikipediaTag OSM "wikipedia" tag like "en:Fort Aguada" (may be null)
     * @param place        the place (used for name search + checking the article is the right one)
     */
    public String getSummary(String wikipediaTag, Place place) {
        if (!networkWorking) return null;

        String title;
        boolean fromTag;
        if (wikipediaTag != null && wikipediaTag.startsWith("en:")) {
            title = wikipediaTag.substring(3);
            fromTag = true;
        } else {
            // name search only for multi-word names (single words like "Cafe" give wrong pages)
            if (!place.getName().contains(" ")) return null;
            title = place.getName();
            fromTag = false;
        }

        String cacheKey = "wiki_" + title.toLowerCase();
        String json = CacheManager.get(cacheKey);
        try {
            if (json == null) {
                json = HttpUtil.get(SUMMARY_URL + HttpUtil.encode(title.replace(' ', '_')), null, 6);
                CacheManager.put(cacheKey, json);
            }
        } catch (IOException e) {
            if (e.getMessage() != null && e.getMessage().startsWith("HTTP ")) {
                CacheManager.put(cacheKey, "{}");   // page doesn't exist - remember that
            } else {
                networkWorking = false;            // no internet - don't keep trying
            }
            return null;
        }

        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            if (!obj.has("extract")) return null;
            if (obj.has("type") && "disambiguation".equals(obj.get("type").getAsString())) return null;

            // For name searches, make sure the article is about a place near OUR place (same name elsewhere = wrong)
            if (!fromTag) {
                if (!obj.has("coordinates")) return null;
                JsonObject c = obj.getAsJsonObject("coordinates");
                double km = HaversineUtil.distanceKm(place.getLat(), place.getLon(),
                        c.get("lat").getAsDouble(), c.get("lon").getAsDouble());
                if (km > 25) return null;
            }
            return firstSentence(obj.get("extract").getAsString());
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** First sentence of the text, without being fooled by abbreviations like "St." or "Mt.". */
    private String firstSentence(String text) {
        int end = text.indexOf(". ");
        while (end > 0) {
            int wordStart = text.lastIndexOf(' ', end - 1) + 1;
            String word = text.substring(wordStart, end);
            boolean abbreviation = word.length() <= 3 && !word.isEmpty() && Character.isUpperCase(word.charAt(0));
            if (!abbreviation) break;
            end = text.indexOf(". ", end + 2);
        }
        String sentence = end > 0 ? text.substring(0, end + 1) : text;
        if (sentence.length() > 170) sentence = sentence.substring(0, 167).trim() + "…";
        return sentence;
    }
}
