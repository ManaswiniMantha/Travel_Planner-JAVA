package travelplanner;

/**
 * One stop in a day: a place with its time slot, cost and the travel needed to reach it.
 */
public class ItineraryItem {

    private Place place;
    private int startMinutes;               // minutes after midnight, e.g. 570 = 9:30 AM
    private int endMinutes;
    private double cost;                    // estimated INR for the whole group
    private double travelDistanceKmFromPrevious;
    private int travelMinutesFromPrevious;
    private boolean distanceLive;           // true = from OpenRouteService, false = Haversine estimate
    private boolean meal;                   // lunch / dinner slot
    private String mealLabel = "";          // "Lunch" or "Dinner"

    public ItineraryItem(Place place, int startMinutes, int endMinutes, double cost,
                         double travelKm, int travelMinutes, boolean distanceLive, boolean meal) {
        this.place = place;
        this.startMinutes = startMinutes;
        this.endMinutes = endMinutes;
        this.cost = cost;
        this.travelDistanceKmFromPrevious = travelKm;
        this.travelMinutesFromPrevious = travelMinutes;
        this.distanceLive = distanceLive;
        this.meal = meal;
    }

    /** Converts minutes-after-midnight into "9:30 AM" style text. */
    public static String formatTime(int minutes) {
        int h = (minutes / 60) % 24;
        int m = minutes % 60;
        String amPm = h < 12 ? "AM" : "PM";
        int h12 = h % 12;
        if (h12 == 0) h12 = 12;
        return String.format("%d:%02d %s", h12, m, amPm);
    }

    /** Formats a duration like "2 hr 15 min" or "25 min". */
    public static String formatDuration(int minutes) {
        if (minutes < 60) return minutes + " min";
        int h = minutes / 60;
        int m = minutes % 60;
        return m == 0 ? h + " hr" : h + " hr " + m + " min";
    }

    public String getStartTime() { return formatTime(startMinutes); }
    public String getEndTime() { return formatTime(endMinutes); }

    public Place getPlace() { return place; }
    public int getStartMinutes() { return startMinutes; }
    public int getEndMinutes() { return endMinutes; }
    public double getCost() { return cost; }
    public double getTravelDistanceKmFromPrevious() { return travelDistanceKmFromPrevious; }
    public int getTravelMinutesFromPrevious() { return travelMinutesFromPrevious; }
    public boolean isDistanceLive() { return distanceLive; }
    public boolean isMeal() { return meal; }
    public String getMealLabel() { return mealLabel; }
    public void setMealLabel(String mealLabel) { this.mealLabel = mealLabel; }
}
