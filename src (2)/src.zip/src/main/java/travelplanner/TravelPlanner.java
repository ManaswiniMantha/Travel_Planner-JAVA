package travelplanner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

/**
 * THE BRAIN OF THE APP. Java makes every decision here:
 *
 *   1. Candidate collection  - geocode destination, fetch real places from OpenStreetMap
 *   2. Cost + duration       - estimated per category, adjusted for the destination country
 *   3. Scoring               - interest match + popularity + affordability + pace - distance
 *   4. Routing               - ONE matrix request for all candidates (Haversine fallback)
 *   5. Greedy day building   - best place first, then "nearest good place" repeatedly,
 *                              with a BUDGET GUARD before every addition
 *   6. Scheduling            - start time + travel + visit duration + buffer, lunch slot
 *
 * Nothing about any city is hard-coded: the same steps run for any destination.
 */
public class TravelPlanner {

    // ===================================================================================
    //  ESTIMATION CONSTANTS - all in ONE place. Every cost is shown as "est." in the UI.
    // ===================================================================================
    private static final double ROAD_FACTOR = 1.3;            // roads are ~30% longer than a straight line
    private static final double AVG_SPEED_KMPH = 35.0;        // average city driving speed (fallback)
    private static final double TRANSPORT_INR_PER_KM = 15.0;  // local taxi/auto fare per vehicle-km (India)
    private static final int TRAVELERS_PER_VEHICLE = 4;       // one taxi carries 4 people
    private static final int LUNCH_TRIGGER = 12 * 60;         // after 12:00 PM we look for lunch
    private static final int LUNCH_EARLIEST = 12 * 60 + 30;   // lunch never starts before 12:30 PM
    private static final int DINNER_EARLIEST = 19 * 60;       // dinner at 7:00 PM (only if Food selected)
    private static final int MAX_CANDIDATES = 40;             // sights we keep after scoring
    private static final int MAX_FOOD_CANDIDATES = 25;        // restaurants we keep for meal slots
    private static final double VARIETY_PENALTY = 15;         // per same-category stop already today
    private static final int MAX_MATRIX_LOCATIONS = 20;       // ONE matrix call with at most 20 points
    private static final double DISTANCE_PENALTY_PER_KM = 4;  // score points lost per km of travel

    /** Base cost per person in INR (India prices). Multiplied by the country factor. */
    private static double baseCostInr(Place p) {
        if (p.hasTag("amenity", "place_of_worship")) return 0;
        if (p.hasTag("leisure", "spa")) return 1500;
        if (p.hasTag("leisure", "garden") || p.hasTag("leisure", "park")) return 50;
        if (p.hasTag("tourism", "theme_park") || p.hasTag("leisure", "water_park")) return 1200;
        if (p.hasTag("historic", "memorial")) return 0;
        if (p.hasTag("amenity", "cafe")) return 250;
        if (p.hasTag("amenity", "food_court")) return 200;
        switch (p.getCategory()) {
            case "Beaches": return 0;
            case "Nature": return 50;
            case "History": return 100;
            case "Culture": return 150;
            case "Food": return 400;
            case "Shopping": return 500;
            case "Adventure": return 800;
            case "Relaxation": return 300;
            default: return 100;       // Sightseeing / general attraction
        }
    }

    /** Typical visit length in minutes (before the pace adjustment). */
    private static int baseDurationMinutes(Place p) {
        if (p.hasTag("amenity", "place_of_worship")) return 45;
        switch (p.getCategory()) {
            case "Beaches": return 120;
            case "Nature": return 90;
            case "History": return 75;
            case "Culture": return 75;
            case "Shopping": return 90;
            case "Adventure": return 120;
            case "Relaxation": return 90;
            case "Food": return 60;
            default: return 60;
        }
    }

    /** Destination cost level compared to India (simple switch on ISO country code). */
    private static double countryCostFactor(String countryCode) {
        switch (countryCode) {
            case "IN": case "": return 1.0;
            case "NP": case "LK": case "BD": case "PK": return 0.9;
            case "TH": case "VN": case "ID": case "MY": return 1.5;
            case "AE": case "SG": case "QA": return 3.0;
            case "FR": case "DE": case "IT": case "ES": case "NL": case "BE": case "AT": case "PT": case "GR":
                return 3.5;
            case "GB": case "US": case "CA": case "AU": case "CH": case "JP": return 4.0;
            default: return 2.0;
        }
    }

    // ===================================================================================

    /** Settings that depend on the travel pace (filled by a switch statement). */
    private static class PaceSettings {
        int minActivities, maxActivities;
        int dayStart, dayEnd;        // minutes after midnight
        int bufferMinutes;           // extra time between stops (parking, tickets, photos...)
        double durationFactor;       // relaxed travellers stay longer at each place
        int lunchMinutes;
    }

    private static PaceSettings paceSettings(String pace) {
        PaceSettings s = new PaceSettings();
        switch (pace) {
            case "Relaxed":
                s.minActivities = 2; s.maxActivities = 3;
                s.dayStart = 10 * 60; s.dayEnd = 19 * 60;
                s.bufferMinutes = 20; s.durationFactor = 1.25; s.lunchMinutes = 75;
                break;
            case "Packed":
                s.minActivities = 5; s.maxActivities = 6;
                s.dayStart = 9 * 60; s.dayEnd = 20 * 60;
                s.bufferMinutes = 10; s.durationFactor = 0.75; s.lunchMinutes = 45;
                break;
            default: // Moderate
                s.minActivities = 3; s.maxActivities = 4;
                s.dayStart = 9 * 60 + 30; s.dayEnd = 19 * 60 + 30;
                s.bufferMinutes = 15; s.durationFactor = 1.0; s.lunchMinutes = 60;
                break;
        }
        return s;
    }

    /** Travel between two places: distance, time and whether it came from live routing. */
    private static class Leg {
        double km;
        int minutes;
        boolean live;

        Leg(double km, int minutes, boolean live) {
            this.km = km;
            this.minutes = minutes;
            this.live = live;
        }
    }

    private final ConfigLoader config;
    private final OpenRouteServiceClient orsClient;
    private final OverpassClient overpassClient = new OverpassClient();
    private final NominatimClient nominatimClient = new NominatimClient();
    private final WikipediaClient wikipediaClient = new WikipediaClient();
    private final CurrencyClient currencyClient = new CurrencyClient();
    private final FallbackData fallbackData = new FallbackData();

    // state for one generate() run
    private MatrixResult matrix;
    private double runningTotal;       // money already planned (places + transport)
    private double transportTotal;
    private boolean budgetBlocked;     // did the budget guard ever reject a place?
    private double costFactor;

    public TravelPlanner(ConfigLoader config, OpenRouteServiceClient orsClient) {
        this.config = config;
        this.orsClient = orsClient;
    }

    /**
     * Builds a complete itinerary. Runs on a background thread (see Main),
     * progress messages are shown on the loading overlay.
     */
    public Itinerary generate(UserPreferences prefs, Consumer<String> progress) {
        Itinerary itinerary = new Itinerary(prefs);
        itinerary.setApiKeyMissing(!config.isApiKeyAvailable());
        matrix = null;
        runningTotal = 0;
        transportTotal = 0;
        budgetBlocked = false;

        // ---------- STEP 1: where is the destination? ----------
        progress.accept("📍 Finding " + prefs.getDestination() + " on the map…");
        GeoLocation dest = locate(prefs.getDestination());
        if (dest == null) {
            throw new IllegalArgumentException("We couldn't find that destination. Try adding the country or state.");
        }
        itinerary.setDestinationLabel(dest.getLabel());
        itinerary.setCountryCode(dest.getCountryCode());
        costFactor = countryCostFactor(dest.getCountryCode());

        // ---------- STEP 1b: candidate places from OpenStreetMap ----------
        progress.accept("📍 Finding places you'll love…");
        double radiusKm = config.getSearchRadiusKm();
        if (dest.isLargeArea()) radiusKm = Math.max(radiusKm, 40);  // states like "Goa" are big
        List<Place> places = fetchPlaces(dest, radiusKm, prefs, itinerary);
        if (places.isEmpty()) {
            throw new IllegalArgumentException("We couldn't find tourist places around " + prefs.getDestination()
                    + ". Try a nearby bigger city, or select more interests.");
        }

        // ---------- STEP 2 + 3: estimate costs, score, sort ----------
        progress.accept("⭐ Scoring " + places.size() + " places…");
        PaceSettings pace = paceSettings(prefs.getPace());
        for (Place p : places) {
            p.setEstimatedCostPerPerson(Math.round(baseCostInr(p) * costFactor));
            int minutes = (int) (baseDurationMinutes(p) * pace.durationFactor);
            p.setEstimatedDurationMinutes(Math.max(30, (minutes / 5) * 5));  // round to 5 minutes
            p.setScore(scorePlace(p, prefs, dest, radiusKm));
        }
        places = removeDuplicates(places);
        Collections.sort(places, Comparator.comparingDouble(Place::getScore).reversed());

        // activities vs. restaurants (restaurants are used for meal slots). Each list keeps its
        // own top-N so restaurants are not pushed out by higher-scoring sights.
        List<Place> activities = new ArrayList<>();
        List<Place> foodPlaces = new ArrayList<>();
        for (Place p : places) {
            if (p.getCategory().equals("Food")) {
                if (foodPlaces.size() < MAX_FOOD_CANDIDATES) foodPlaces.add(p);
            } else if (activities.size() < MAX_CANDIDATES) {
                activities.add(p);
            }
        }

        // ---------- STEP 4: ONE matrix request for the best candidates ----------
        progress.accept("🛣 Calculating routes…");
        List<Place> matrixPool = new ArrayList<>();
        int foodSlots = Math.min(foodPlaces.size(), 6);
        int activitySlots = Math.min(activities.size(), MAX_MATRIX_LOCATIONS - foodSlots);
        matrixPool.addAll(activities.subList(0, activitySlots));
        matrixPool.addAll(foodPlaces.subList(0, foodSlots));
        List<double[]> points = new ArrayList<>();
        for (int i = 0; i < matrixPool.size(); i++) {
            matrixPool.get(i).setMatrixIndex(i);
            points.add(new double[]{matrixPool.get(i).getLat(), matrixPool.get(i).getLon()});
        }
        if (config.isApiKeyAvailable() && points.size() >= 2) {
            try {
                matrix = orsClient.getMatrix(points);
            } catch (IOException e) {
                // FALLBACK 1: no live routing -> Haversine estimates (itinerary still works)
                System.out.println("Matrix API failed: " + e.getMessage());
                matrix = null;
            }
        }
        itinerary.setUsedLiveRouting(matrix != null);

        // start location -> destination (shown in the header only)
        progress.accept("🛣 Measuring your journey from " + prefs.getStartLocation() + "…");
        calculateStartDistance(prefs, dest, itinerary);

        // ---------- STEP 5 + 6: greedy day building + scheduling ----------
        progress.accept("💡 Building your itinerary…");
        buildDays(prefs, pace, activities, foodPlaces, itinerary);

        // ---------- extras: descriptions + local currency ----------
        progress.accept("📖 Adding place descriptions…");
        addDescriptions(itinerary);
        String currency = CurrencyClient.currencyForCountry(dest.getCountryCode());
        if (!currency.equals("INR")) {
            itinerary.setCurrency(currency, CurrencyClient.symbolFor(currency), currencyClient.getRateFromInr(currency));
        }

        itinerary.calculateTotals(transportTotal);
        addFriendlyNotes(itinerary, pace, prefs);
        return itinerary;
    }

    // ------------------------------------------------------------------ STEP 1 helpers

    /** Geocoder chain: HeiGIT -> Nominatim -> offline demo cities. Returns null if not found. */
    private GeoLocation locate(String text) {
        try {
            GeoLocation g = orsClient.geocode(text);
            if (g != null) return g;
        } catch (IOException | RuntimeException e) {
            System.out.println("HeiGIT geocoder failed: " + e.getMessage());
        }
        try {
            GeoLocation g = nominatimClient.geocode(text);
            if (g != null) return g;
        } catch (IOException | RuntimeException e) {
            System.out.println("Nominatim failed: " + e.getMessage());
        }
        return fallbackData.geocode(text);
    }

    /** Overpass (with cache + mirror) -> offline demo file. */
    private List<Place> fetchPlaces(GeoLocation dest, double radiusKm, UserPreferences prefs, Itinerary itinerary) {
        List<Place> places = new ArrayList<>();
        try {
            places = overpassClient.findPlaces(dest.getLat(), dest.getLon(), radiusKm, prefs.getInterests(), dest.isLargeArea());
            // small town with few results -> try once more with double the radius
            if (places.size() < 8 && radiusKm < 40) {
                places = overpassClient.findPlaces(dest.getLat(), dest.getLon(), radiusKm * 2, prefs.getInterests(), dest.isLargeArea());
            }
        } catch (IOException | RuntimeException e) {
            System.out.println("Overpass failed: " + e.getMessage());
        }
        if (places.isEmpty()) {
            // FALLBACK 2: offline demo places (the itinerary is still built by the algorithm below)
            places = fallbackData.placesNear(dest.getLat(), dest.getLon());
            if (!places.isEmpty()) itinerary.setUsingOfflineData(true);
        }
        return places;
    }

    // ------------------------------------------------------------------ STEP 2: scoring

    /**
     * Simple, explainable score:
     *  +50 per matching interest (max 2 counted)  -> places you care about come first
     *  +20 popularity proxy (Wikipedia/website/attraction tag; OSM has no ratings)
     *  +20 / +10 if cheap compared to the per-person daily budget
     *  +10 if it suits the chosen pace
     *  - up to 20 points the further it is from the destination centre
     *  -30 if the name has no Latin letters (unreadable in an English UI)
     */
    private double scorePlace(Place p, UserPreferences prefs, GeoLocation dest, double radiusKm) {
        double score = 0;

        int matches = 0;
        for (String interest : p.getMatchingInterests()) {
            if (prefs.hasInterest(interest)) matches++;
        }
        score += 50 * Math.min(matches, 2);

        if (p.isPopular()) score += 20;

        double perPersonPerDay = prefs.getBudget() / prefs.getTravelers() / prefs.getDays();
        double cost = p.getEstimatedCostPerPerson();
        if (cost <= 0.30 * perPersonPerDay) score += 20;
        else if (cost <= 0.50 * perPersonPerDay) score += 10;

        String c = p.getCategory();
        switch (prefs.getPace()) {
            case "Relaxed":
                if (c.equals("Beaches") || c.equals("Nature") || c.equals("Relaxation") || p.hasTag("amenity", "cafe")) {
                    score += 10;
                }
                break;
            case "Packed":
                if (p.getEstimatedDurationMinutes() <= 75) score += 10;
                break;
            default:
                if (c.equals("History") || c.equals("Culture") || c.equals("Sightseeing")) score += 10;
                break;
        }

        // Distance from the centre. Skipped for big regions (a state like Goa): their geometric
        // centre can be inland forest, which would wrongly punish the famous coastal places.
        if (!dest.isLargeArea()) {
            double kmFromCentre = HaversineUtil.distanceKm(dest.getLat(), dest.getLon(), p.getLat(), p.getLon());
            score -= Math.min(20, kmFromCentre / radiusKm * 20);
        }

        // the app is in English: names without any Latin letters go to the back of the queue
        if (!p.getName().matches(".*[A-Za-z].*")) score -= 30;
        return score;
    }

    /**
     * Removes duplicates: same name, same Wikidata ID (one landmark mapped twice, e.g. a fort
     * and its walls), or two places of the same category within 150 m.
     */
    private List<Place> removeDuplicates(List<Place> places) {
        List<Place> unique = new ArrayList<>();
        for (Place p : places) {
            boolean duplicate = false;
            for (Place u : unique) {
                boolean sameName = u.getName().equalsIgnoreCase(p.getName());
                boolean sameWikidata = p.getTag("wikidata") != null && p.getTag("wikidata").equals(u.getTag("wikidata"));
                boolean sameCategory = u.getCategory().equals(p.getCategory());
                double km = HaversineUtil.distanceKm(u, p);
                boolean sameSpot = sameCategory && km < 0.15;
                // "Fort Aguada" vs "Aguada Fortress": same category, close by, share a distinctive word
                boolean similarName = sameCategory && km < 2 && shareDistinctiveWord(u.getName(), p.getName());
                if (sameName || sameWikidata || sameSpot || similarName) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) unique.add(p);
        }
        return unique;
    }

    /** Words that appear in many place names, so sharing them proves nothing. */
    private static final String[] GENERIC_WORDS = {"fort", "fortress", "beach", "temple", "church", "park",
            "museum", "garden", "gardens", "market", "lake", "palace", "cathedral", "basilica", "chapel",
            "mosque", "monument", "memorial", "ruins", "statue", "the", "and", "of", "saint", "national"};

    private boolean shareDistinctiveWord(String a, String b) {
        String[] wordsA = a.toLowerCase().split("[^a-z]+");
        String bLower = " " + b.toLowerCase().replaceAll("[^a-z]+", " ") + " ";
        for (String w : wordsA) {
            if (w.length() < 4) continue;
            boolean generic = false;
            for (String g : GENERIC_WORDS) {
                if (g.equals(w)) {
                    generic = true;
                    break;
                }
            }
            if (!generic && bLower.contains(" " + w + " ")) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ STEP 4: routing

    /** Travel from a to b: live matrix value if available, otherwise Haversine estimate. */
    private Leg travel(Place a, Place b) {
        int i = a.getMatrixIndex();
        int j = b.getMatrixIndex();
        if (matrix != null && i >= 0 && j >= 0 && matrix.getKm(i, j) >= 0) {
            return new Leg(matrix.getKm(i, j), (int) Math.round(matrix.getMinutes(i, j)), true);
        }
        // FALLBACK: straight line x road factor, at an average city speed
        double km = HaversineUtil.distanceKm(a, b) * ROAD_FACTOR;
        int minutes = (int) Math.round(km / AVG_SPEED_KMPH * 60);
        return new Leg(km, minutes, false);
    }

    /** Local transport estimate for one leg (per vehicle, not per person). */
    private double transportCost(double km, int travelers) {
        int vehicles = (travelers + TRAVELERS_PER_VEHICLE - 1) / TRAVELERS_PER_VEHICLE;
        return Math.round(km * TRANSPORT_INR_PER_KM * costFactor * vehicles);
    }

    private void calculateStartDistance(UserPreferences prefs, GeoLocation dest, Itinerary itinerary) {
        GeoLocation start = locate(prefs.getStartLocation());
        if (start == null) {
            itinerary.setStartLabel(prefs.getStartLocation());
            return;
        }
        itinerary.setStartLabel(start.getLabel());
        double straightKm = HaversineUtil.distanceKm(start.getLat(), start.getLon(), dest.getLat(), dest.getLon());
        double km = -1;
        if (config.isApiKeyAvailable() && straightKm < 3000) {
            try {
                List<double[]> two = new ArrayList<>();
                two.add(new double[]{start.getLat(), start.getLon()});
                two.add(new double[]{dest.getLat(), dest.getLon()});
                km = orsClient.getMatrix(two).getKm(0, 1);   // -1 if there is no road (e.g. across the sea)
            } catch (IOException | RuntimeException e) {
                km = -1;
            }
        }
        if (km > 0) {
            itinerary.setStartToDestinationKm(km);
            itinerary.setStartDistanceIsRoad(true);
        } else {
            itinerary.setStartToDestinationKm(straightKm);
            itinerary.setStartDistanceIsRoad(false);
        }
        if (straightKm > 800) itinerary.setTravelModeHint("✈ Consider flying");
        else if (straightKm > 300) itinerary.setTravelModeHint("🚆 Train or flight recommended");
        else if (straightKm > 20) itinerary.setTravelModeHint("🚗 Comfortable by road");
        else itinerary.setTravelModeHint("You're already close by!");
    }

    // ------------------------------------------------------------------ STEP 5 + 6: build the days

    private void buildDays(UserPreferences prefs, PaceSettings pace, List<Place> activities,
                           List<Place> foodPlaces, Itinerary itinerary) {
        int travelers = prefs.getTravelers();
        double lunchReserve = Math.round(250 * costFactor) * travelers;   // cheap lunch money kept aside

        for (int d = 0; d < prefs.getDays(); d++) {
            // DAILY BUDGET: the money still left is split evenly over the remaining days, so day 1
            // can't spend everything. Money not spent today automatically rolls over to tomorrow.
            double dayLimit = runningTotal + (prefs.getBudget() - runningTotal) / (prefs.getDays() - d);

            ArrayList<ItineraryItem> day = new ArrayList<>();
            ArrayList<String> categoriesToday = new ArrayList<>();
            int time = pace.dayStart;
            Place previous = null;
            int activityCount = 0;
            boolean lunchDone = false;

            while (activityCount < pace.maxActivities) {
                // lunch slot once the clock passes 12:00
                if (!lunchDone && previous != null && time >= LUNCH_TRIGGER) {
                    ItineraryItem lunch = planMeal("Lunch", previous, time, LUNCH_EARLIEST, pace.lunchMinutes,
                            foodPlaces, travelers, dayLimit);
                    lunchDone = true;
                    if (lunch != null) {
                        day.add(lunch);
                        time = lunch.getEndMinutes();
                        previous = lunch.getPlace();
                    }
                    continue;
                }

                // until lunch is planned, keep some money aside for it
                double spendable = dayLimit - (lunchDone ? 0 : lunchReserve);
                Place next = pickNextActivity(previous, time, activities, pace, travelers, spendable, categoriesToday);
                if (next == null) break;   // nothing fits in time or budget today

                Leg leg = previous == null ? new Leg(0, 0, true) : travel(previous, next);
                int arrive = previous == null ? time : time + leg.minutes + pace.bufferMinutes;
                int leave = arrive + next.getEstimatedDurationMinutes();
                double cost = next.getEstimatedCostPerPerson() * travelers;
                double legTransport = transportCost(leg.km, travelers);

                day.add(new ItineraryItem(next, arrive, leave, cost, leg.km, leg.minutes, leg.live, false));
                next.setUsed(true);
                categoriesToday.add(next.getCategory());
                runningTotal += cost + legTransport;
                transportTotal += legTransport;
                time = leave;
                previous = next;
                activityCount++;
            }

            // short day that ended before lunch -> still add lunch if it's not too late
            if (!lunchDone && previous != null && time <= 15 * 60) {
                ItineraryItem lunch = planMeal("Lunch", previous, time, LUNCH_EARLIEST, pace.lunchMinutes,
                        foodPlaces, travelers, dayLimit);
                if (lunch != null) {
                    day.add(lunch);
                    previous = lunch.getPlace();
                    time = lunch.getEndMinutes();
                }
            }
            // food lovers get a dinner recommendation too
            if (prefs.hasInterest("Food") && previous != null) {
                ItineraryItem dinner = planMeal("Dinner", previous, time, DINNER_EARLIEST, 75,
                        foodPlaces, travelers, dayLimit);
                if (dinner != null) day.add(dinner);
            }
            itinerary.addDay(day);
        }
    }

    /**
     * GREEDY NEAREST-NEIGHBOUR choice of the next activity.
     *  - first stop of the day: the highest-scoring unused place (days naturally cluster around it)
     *  - later stops: maximise  score - distancePenalty - varietyPenalty  (good AND close AND different)
     * BUDGET GUARD: a place is skipped if runningTotal + its cost would exceed today's budget.
     * TIME GUARD: a place is skipped if the visit would end after the day's end time.
     */
    private Place pickNextActivity(Place previous, int time, List<Place> activities, PaceSettings pace,
                                   int travelers, double spendableBudget, ArrayList<String> categoriesToday) {
        Place best = null;
        double bestValue = Double.NEGATIVE_INFINITY;
        for (Place p : activities) {
            if (p.isUsed()) continue;

            Leg leg = previous == null ? new Leg(0, 0, true) : travel(previous, p);
            int arrive = previous == null ? time : time + leg.minutes + pace.bufferMinutes;
            if (arrive + p.getEstimatedDurationMinutes() > pace.dayEnd) continue;   // TIME GUARD

            double cost = p.getEstimatedCostPerPerson() * travelers + transportCost(leg.km, travelers);
            if (runningTotal + cost > spendableBudget) {                            // BUDGET GUARD
                budgetBlocked = true;
                continue;   // try cheaper alternatives instead
            }

            int sameCategory = 0;
            for (String c : categoriesToday) {
                if (c.equals(p.getCategory())) sameCategory++;
            }
            double value = p.getScore() - leg.km * DISTANCE_PENALTY_PER_KM - sameCategory * VARIETY_PENALTY;
            if (value > bestValue) {
                bestValue = value;
                best = p;
            }
        }
        return best;
    }

    /**
     * Picks a restaurant near the previous stop for lunch/dinner (nearby matters twice as much).
     * If no listed restaurant is affordable/nearby we suggest a "local eatery" at the same spot.
     */
    private ItineraryItem planMeal(String label, Place previous, int time, int earliest, int duration,
                                   List<Place> foodPlaces, int travelers, double dayLimit) {
        Place best = null;
        Leg bestLeg = null;
        double bestValue = Double.NEGATIVE_INFINITY;
        for (Place f : foodPlaces) {
            if (f.isUsed()) continue;
            Leg leg = travel(previous, f);
            if (leg.km > 15) continue;   // too far for a meal break
            double cost = f.getEstimatedCostPerPerson() * travelers + transportCost(leg.km, travelers);
            if (runningTotal + cost > dayLimit) {
                budgetBlocked = true;
                continue;
            }
            double value = f.getScore() - leg.km * DISTANCE_PENALTY_PER_KM * 2;
            if (value > bestValue) {
                bestValue = value;
                best = f;
                bestLeg = leg;
            }
        }

        if (best == null) {
            // generic suggestion right where the traveller already is (cheaper local food)
            String nearName = previous.getName().replace("Local eatery near ", "");
            best = new Place("Local eatery near " + nearName, previous.getLat(), previous.getLon(), "Food");
            best.setEstimatedCostPerPerson(Math.round(250 * costFactor));
            best.setDescription("No listed restaurant close by, so grab a meal at a local eatery here.");
            bestLeg = new Leg(0, 0, true);
            if (runningTotal + best.getEstimatedCostPerPerson() * travelers > dayLimit) {
                return null;   // not even a cheap meal fits the budget
            }
        }

        int arrive = Math.max(time + bestLeg.minutes, earliest);
        double cost = best.getEstimatedCostPerPerson() * travelers;
        double legTransport = transportCost(bestLeg.km, travelers);
        ItineraryItem meal = new ItineraryItem(best, arrive, arrive + duration, cost,
                bestLeg.km, bestLeg.minutes, bestLeg.live, true);
        meal.setMealLabel(label);
        best.setUsed(true);
        runningTotal += cost + legTransport;
        transportTotal += legTransport;
        return meal;
    }

    // ------------------------------------------------------------------ extras

    /** Wikipedia summary for chosen places only (never for all candidates), else a generic line. */
    private void addDescriptions(Itinerary itinerary) {
        for (ArrayList<ItineraryItem> day : itinerary.getDays()) {
            for (ItineraryItem item : day) {
                Place p = item.getPlace();
                if (!p.getDescription().isEmpty()) continue;
                String text = p.getTag("description");
                // ignore junk descriptions in OSM (e.g. just "4.4")
                if (text != null && (text.length() < 15 || !text.matches(".*[A-Za-z]{3,}.*"))) text = null;
                if (text == null && !p.getCategory().equals("Food")) {
                    text = wikipediaClient.getSummary(p.getTag("wikipedia"), p);
                }
                if (text == null || text.isBlank()) text = genericDescription(p);
                p.setDescription(text);
            }
        }
    }

    private String genericDescription(Place p) {
        switch (p.getCategory()) {
            case "Beaches": return "A sandy beach - perfect for a stroll, the sunset and some sea breeze.";
            case "History": return "A historic " + tagOr(p, "historic", "landmark").replace('_', ' ')
                    + " worth exploring for its story and architecture.";
            case "Culture":
                if (p.hasTag("amenity", "place_of_worship")) return "A place of worship known for its peaceful atmosphere and architecture.";
                if (p.hasTag("tourism", "museum")) return "A museum worth exploring for its collections and local heritage.";
                if (p.hasTag("tourism", "gallery")) return "An art gallery featuring local and visiting artists.";
                if (p.hasTag("amenity", "theatre")) return "A theatre - check what's on during your visit.";
                if (p.hasTag("historic", "archaeological_site")) return "An archaeological site that reveals the area's ancient past.";
                return "A cultural spot with local art and heritage.";
            case "Nature": return "Green, open space to enjoy nature and fresh air.";
            case "Food":
                String cuisine = p.getTag("cuisine");
                return cuisine != null
                        ? "Popular for " + cuisine.replace(';', ',').replace('_', ' ') + " food."
                        : "A well-rated local spot to refuel.";
            case "Shopping": return "Browse local shops and pick up souvenirs.";
            case "Adventure": return "Get your adrenaline going with fun activities here.";
            case "Relaxation": return "Unwind and recharge at a calm, relaxing spot.";
            default: return "A popular local attraction worth a visit.";
        }
    }

    private String tagOr(Place p, String key, String fallback) {
        String v = p.getTag(key);
        return (v == null || v.equals("yes")) ? fallback : v;
    }

    private void addFriendlyNotes(Itinerary itinerary, PaceSettings pace, UserPreferences prefs) {
        int wanted = pace.minActivities * prefs.getDays();
        int got = itinerary.getActivityCount();
        if (got < wanted && budgetBlocked) {
            itinerary.getNotes().add("Your budget only covered " + got + " activities. Increase budget for more.");
        } else if (got < wanted) {
            itinerary.getNotes().add("We found only " + got + " matching places nearby, so some days are lighter. "
                    + "Try selecting more interests for a fuller plan.");
        }
    }
}
